package group_project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Logout {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		obj.maximizeBrowser(driver);
		obj.enterEmail(driver, "pradeep33reigns@gmail.com");
        obj.enterPassword(driver, "pradeep345");
        obj.clickOnLoginButton(driver);
        obj.clickOnLogOutButton(driver);
        
        obj.closeBrowser(driver);


	}

}
